package com.geecreative.bookkeeper

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      MaterialTheme {
        val vm: TxnViewModel = viewModel(factory = TxnViewModel.factory(application))
        AppScreen(vm)
      }
    }
  }
}

@Composable
fun AppScreen(vm: TxnViewModel){
  var tab by remember { mutableStateOf(0) }
  Column(Modifier.fillMaxSize()) {
    TabRow(selectedTabIndex = tab) {
      Tab(text={ Text("Transaksi") }, selected=tab==0, onClick={ tab=0 })
      Tab(text={ Text("Laporan") }, selected=tab==1, onClick={ tab=1 })
      Tab(text={ Text("Ekspor") }, selected=tab==2, onClick={ tab=2 })
      Tab(text={ Text("Pengaturan") }, selected=tab==3, onClick={ tab=3 })
    }
    when(tab){
      0 -> TransaksiTab(vm)
      1 -> LaporanTab(vm)
      2 -> EksporTab(vm)
      3 -> PengaturanTab(vm)
    }
  }
}

@Composable
fun TransaksiTab(vm: TxnViewModel){
  var text by remember { mutableStateOf("+TXN\nTanggal: 2025-10-07\nMerek: Gee Creative\nNomor: INV-0001\nUraian: Desain retainer\nRincian:\n- 1102 Piutang Usaha 5.550.000 Debet\n- 4101 Pendapatan Jasa Desain 5.000.000 Kredit\n- 2200 PPN Keluaran 550.000 Kredit\nPajak: PPN11") }
  var status by remember { mutableStateOf("Debet dan Kredit harus seimbang.") }
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    OutlinedTextField(value=text, onValueChange={ text=it }, minLines=7, label={ Text("Tempel +TXN (Bahasa Indonesia)") }, modifier=Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    Button(onClick={
      try {
        vm.addFromText(text)
        text=""
        status="Tersimpan. Debet=Kredit."
      } catch (t:Throwable){
        status=t.message ?: "Gagal menyimpan"
      }
    }){ Text("Simpan ke Jurnal") }
    Spacer(Modifier.height(12.dp))
    Text(status, color = MaterialTheme.colorScheme.secondary)
    Spacer(Modifier.height(12.dp))
    Text("Daftar Jurnal", style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    LazyColumn {
      items(vm.entries){ e ->
        Text("• " + e.tanggal + " • " + (e.nomor ?: "(tanpa nomor)") + " • " + (e.uraian ?: ""))
        Spacer(Modifier.height(6.dp))
      }
    }
  }
}

@Composable
fun LaporanTab(vm: TxnViewModel){
  val tb = vm.trialBalance()
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text("Neraca Saldo", style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    LazyColumn {
      items(tb.rows){ r ->
        Text("${r.code} ${r.name} — Debet: Rp ${r.debet} | Kredit: Rp ${r.kredit}")
        Spacer(Modifier.height(6.dp))
      }
      item { Spacer(Modifier.height(8.dp)); Text("Total Debet: Rp ${tb.totalDebet} | Total Kredit: Rp ${tb.totalKredit}") }
    }
    Spacer(Modifier.height(16.dp))
    val pl = vm.labaRugi()
    Text("Laba Rugi", style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(6.dp))
    Text("Pendapatan: Rp " + pl.pendapatan)
    Text("HPP: Rp " + pl.hpp)
    Text("Laba Kotor: Rp " + pl.labaKotor)
    Text("Beban: Rp " + pl.beban)
    Text("Laba/(Rugi) Bersih: Rp " + pl.labaBersih)
  }
}

@Composable
fun EksporTab(vm: TxnViewModel){
  val launcherCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
    uri?.let { vm.exportCsv(it) }
  }
  val launcherJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
    uri?.let { vm.exportJson(it) }
  }
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text("Ekspor", style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Row { Button(onClick={ launcherCsv.launch("jurnal.csv") }){ Text("Unduh Jurnal (CSV)") }
          Spacer(Modifier.width(12.dp))
          Button(onClick={ launcherJson.launch("jurnal.json") }, colors=ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)){ Text("Unduh Jurnal (JSON)") } }
  }
}

@Composable
fun PengaturanTab(vm: TxnViewModel){
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text("Pengaturan", style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("Periode fiskal tersimpan di perangkat.")
  }
}