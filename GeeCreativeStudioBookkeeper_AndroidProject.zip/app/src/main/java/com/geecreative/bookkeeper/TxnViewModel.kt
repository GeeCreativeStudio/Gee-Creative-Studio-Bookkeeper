package com.geecreative.bookkeeper

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter

data class Line(val akun:Int, val debet:Long, val kredit:Long)
data class Entry(
  val tanggal: String,
  val merek: String?,
  val proyekId: String?,
  val nomor: String?,
  val pihakId: String?,
  val uraian: String?,
  val pajak: String?,
  val lines: List<Line>
)
data class TbRow(val code:Int, val name:String, val type:String, val normal:String, val debet:Long, val kredit:Long)
data class TrialBalance(val rows: List<TbRow>, val totalDebet: Long, val totalKredit: Long)
data class PL(val pendapatan:Long, val hpp:Long, val beban:Long, val labaKotor:Long, val labaBersih:Long)

class TxnViewModel(app: Application): AndroidViewModel(app) {
  companion object { fun factory(app: Application) = object: ViewModelProvider.Factory{
    @Suppress("UNCHECKED_CAST") override fun <T: ViewModel> create(modelClass: Class<T>): T = TxnViewModel(app) as T } }

  private val prefs = app.getSharedPreferences("gcs_bookkeeper", Context.MODE_PRIVATE)
  private val coa = listOf(
    arrayOf(1100, "Kas Kecil", "Aset", "Debet"),
    arrayOf(1101, "Bank - BCA", "Aset", "Debet"),
    arrayOf(1102, "Piutang Usaha", "Aset", "Debet"),
    arrayOf(1200, "Persediaan Barang", "Aset", "Debet"),
    arrayOf(1400, "PPN Masukan", "Aset", "Debet"),
    arrayOf(1500, "Peralatan & Perlengkapan Studio", "Aset", "Debet"),
    arrayOf(1501, "Akumulasi Penyusutan", "Aset (Kontra)", "Kredit"),
    arrayOf(2100, "Hutang Usaha", "Kewajiban", "Kredit"),
    arrayOf(2200, "PPN Keluaran", "Kewajiban", "Kredit"),
    arrayOf(3100, "Modal Pemilik", "Ekuitas", "Kredit"),
    arrayOf(3200, "Laba Ditahan", "Ekuitas", "Kredit"),
    arrayOf(3300, "Laba/Rugi Berjalan", "Ekuitas", "Kredit"),
    arrayOf(4101, "Pendapatan Jasa Desain", "Pendapatan", "Kredit"),
    arrayOf(4102, "Pendapatan Produksi Konten/Video", "Pendapatan", "Kredit"),
    arrayOf(4107, "Pendapatan Merchandise", "Pendapatan", "Kredit"),
    arrayOf(5100, "Harga Pokok Penjualan Merchandise", "HPP", "Debet"),
    arrayOf(6100, "Gaji & Upah Karyawan", "Beban", "Debet"),
    arrayOf(6230, "Penyusutan Aset Tetap", "Beban", "Debet"),
    arrayOf(6260, "Perangkat Lunak & Langganan", "Beban", "Debet"),
    arrayOf(6290, "Biaya Kantor", "Beban", "Debet"),
    arrayOf(7100, "Pendapatan Lain", "Pendapatan Lain", "Kredit"),
    arrayOf(7300, "Beban Lain", "Beban Lain", "Debet")
  )

  var entries: List<Entry> = loadEntries(); private set

  private fun loadEntries(): List<Entry> {
    val json = prefs.getString("entries","[]") ?: "[]"
    val arr = JSONArray(json)
    val list = mutableListOf<Entry>()
    for(i in 0 until arr.length()){
      val o = arr.getJSONObject(i)
      val linesJson = o.getJSONArray("lines")
      val lines = mutableListOf<Line>()
      for(j in 0 until linesJson.length()){
        val l = linesJson.getJSONObject(j)
        lines += Line(l.getInt("akun"), l.getLong("debet"), l.getLong("kredit"))
      }
      list += Entry(
        o.getString("tanggal"),
        o.optString("merek", null),
        o.optString("proyekId", null),
        o.optString("nomor", null),
        o.optString("pihakId", null),
        o.optString("uraian", null),
        o.optString("pajak", null),
        lines
      )
    }
    return list
  }

  private fun saveEntries(){
    val arr = JSONArray()
    entries.forEach { e ->
      val o = JSONObject()
      o.put("tanggal", e.tanggal)
      o.put("merek", e.merek)
      o.put("proyekId", e.proyekId)
      o.put("nomor", e.nomor)
      o.put("pihakId", e.pihakId)
      o.put("uraian", e.uraian)
      o.put("pajak", e.pajak)
      val ls = JSONArray()
      e.lines.forEach { l ->
        val lo = JSONObject()
        lo.put("akun", l.akun); lo.put("debet", l.debet); lo.put("kredit", l.kredit)
        ls.put(lo)
      }
      o.put("lines", ls)
      arr.put(o)
    }
    prefs.edit().putString("entries", arr.toString()).apply()
  }

  private fun parseAmount(s:String): Long = s.replace(".","").trim().toLong()

  fun addFromText(text:String){
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    require(lines.first().equals("+TXN", ignoreCase = true)) { "Format harus diawali +TXN" }
    var tanggal: String? = null; var merek: String? = null; var proyek: String? = null
    var nomor: String? = null; var pihak: String? = null; var uraian: String? = null
    var pajak: String? = null; val detil = mutableListOf<Line>()
    var inR = false
    lines.drop(1).forEach { l ->
      when {
        l.startsWith("Tanggal:", true) -> tanggal = l.substringAfter(":").trim()
        l.startsWith("Merek:", true) -> merek = l.substringAfter(":").trim()
        l.startsWith("KodeProyek:", true) -> proyek = l.substringAfter(":").trim()
        l.startsWith("Nomor:", true) -> nomor = l.substringAfter(":").trim()
        l.startsWith("Pihak:", true) -> pihak = l.substringAfter(":").trim()
        l.startsWith("Uraian:", true) -> uraian = l.substringAfter(":").trim()
        l.startsWith("Pajak:", true) -> pajak = l.substringAfter(":").trim()
        l.startsWith("Rincian:", true) -> inR = true
        inR && l.startsWith("- ") -> {
          // Gunakan string biasa (bukan triple quotes) agar aman saat dibundel lewat generator Python
          val regex = Regex("- +(\\d{3,4}) +.+ +([\\d\\.]+) +(Debet|Kredit)", RegexOption.IGNORE_CASE)
          val m = regex.find(l) ?: throw IllegalArgumentException("Baris rincian tidak valid: " + l)
          val code = m.groupValues[1].toInt()
          val amt = parseAmount(m.groupValues[2])
          val side = m.groupValues[3].lowercase()
          detil += if(side=="debet") Line(code, amt, 0) else Line(code, 0, amt)
        }
      }
    }
    val entry = Entry(
      tanggal ?: throw IllegalArgumentException("Tanggal wajib"), merek, proyek, nomor, pihak, uraian, pajak, detil
    )
    val d = detil.sumOf { it.debet }; val k = detil.sumOf { it.kredit }
    require(d==k) { "Debet dan Kredit harus sama" }
    entries = listOf(entry) + entries
    saveEntries()
  }

  fun trialBalance(): TrialBalance {
    val map = mutableMapOf<Int, Pair<Long,Long>>()
    entries.forEach { e -> e.lines.forEach { l ->
      val cur = map[l.akun] ?: (0L to 0L)
      map[l.akun] = (cur.first + l.debet) to (cur.second + l.kredit)
    } }
    val rows = mutableListOf<TbRow>()
    var td=0L; var tk=0L
    for (a in coa) {
      val code = a[0] as Int
      val name = a[1] as String
      val type = a[2] as String
      val normal = a[3] as String
      val s = map[code] ?: (0L to 0L)
      if(s.first!=0L || s.second!=0L){
        rows += TbRow(code, name, type, normal, s.first, s.second)
      }
      td += s.first; tk += s.second
    }
    return TrialBalance(rows, td, tk)
  }

  fun labaRugi(): PL {
    val sums = mutableMapOf<Int, Pair<Long,Long>>()
    entries.forEach { e -> e.lines.forEach { l ->
      val cur = sums[l.akun] ?: (0L to 0L)
      sums[l.akun] = (cur.first + l.debet) to (cur.second + l.kredit)
    } }
    fun sumType(vararg types: String): Pair<Long,Long> {
      var d=0L; var k=0L
      for (a in coa) {
        if(types.contains(a[2])) {
          val s = sums[a[0] as Int] ?: (0L to 0L)
          d += s.first; k += s.second
        }
      }
      return d to k
    }
    val (dRev, kRev) = sumType("Pendapatan","Pendapatan Lain")
    val (dHpp, kHpp) = sumType("HPP")
    val (dBeb, kBeb) = sumType("Beban","Beban Lain")
    val pendapatan = kRev - dRev
    val hpp = dHpp - kHpp
    val labaKotor = pendapatan - hpp
    val beban = dBeb - kBeb
    val labaBersih = labaKotor - beban
    return PL(pendapatan, hpp, beban, labaKotor, labaBersih)
  }

  fun exportCsv(uri: Uri){
    val ctx = getApplication<Application>()

    ctx.contentResolver.openOutputStream(uri)?.use { os ->
      OutputStreamWriter(os).use { w ->
        w.appendLine("Tanggal,Merek,KodeProyek,Nomor,Pihak,Uraian,Pajak,Akun,Debet,Kredit")
        for (e in entries) {
          for (l in e.lines) {
            val row = listOf(e.tanggal, e.merek?:"", e.proyekId?:"", e.nomor?:"", e.pihakId?:"", e.uraian?:"", e.pajak?:"", l.akun.toString(), l.debet.toString(), l.kredit.toString())
            w.appendLine(row.joinToString(","))
          }
        }
      }
    }
  }

  fun exportJson(uri: Uri){
    val ctx = getApplication<Application>()
    val arr = JSONArray()
    for (e in entries) {
      val o = JSONObject()
      o.put("tanggal", e.tanggal); o.put("merek", e.merek); o.put("proyekId", e.proyekId)
      o.put("nomor", e.nomor); o.put("pihakId", e.pihakId); o.put("uraian", e.uraian); o.put("pajak", e.pajak)
      val ls = JSONArray()
      for (l in e.lines) {
        val lo = JSONObject(); lo.put("akun", l.akun); lo.put("debet", l.debet); lo.put("kredit", l.kredit)
        ls.put(lo)
      }
      o.put("lines", ls); arr.put(o)
    }
    val json = arr.toString(2)
    ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
  }
}