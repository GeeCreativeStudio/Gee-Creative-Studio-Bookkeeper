# Gee Creative Studio Bookkeeper (Android)

Aplikasi Android untuk pencatatan jurnal **+TXN (Bahasa Indonesia)**, daftar jurnal, laporan ringkas, dan ekspor CSV/JSON.

## Cara mendapatkan APK tanpa Android Studio
1. Buat repo kosong di GitHub.
2. Unggah semua isi folder ini ke repo tersebut.
3. Buka tab **Actions** → workflow **Build Debug APK** berjalan otomatis atau klik **Run workflow**.
4. Setelah selesai, **Artifacts** akan berisi `app-debug.apk`. Unduh dan pasang di HP Android.

> APK yang dihasilkan adalah **debug APK** (sudah ditandatangani debug key), bisa diinstal langsung.

## Format transaksi contoh
```
+TXN
Tanggal: 2025-10-07
Merek: Gee Creative
Nomor: INV-0001
Uraian: Desain retainer September
Rincian:
- 1102 Piutang Usaha 5.550.000 Debet
- 4101 Pendapatan Jasa Desain 5.000.000 Kredit
- 2200 PPN Keluaran 550.000 Kredit
Pajak: PPN11
```